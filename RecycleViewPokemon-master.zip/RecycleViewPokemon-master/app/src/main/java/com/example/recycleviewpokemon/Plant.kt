package com.example.recycleviewpokemon

data class Plant(val imageId: Int, val title: String)

